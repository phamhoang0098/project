<?php
    return [
        'paths' => [
            'resource' => 'img',
        ],
];