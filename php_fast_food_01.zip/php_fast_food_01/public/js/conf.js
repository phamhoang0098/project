var admin_role;
$(document).ready(function(){
	admin_role = $('.admin_role').html();
})